<?php
	require_once('auth.php');
?>

<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=900, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>List of Students</title>'); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 900px; font-size:16px; font-family:arial;">');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>
<div id="print_content">	
<table cellpadding="5" cellspacing="0" id="resultTable" border="1">
		<tr>
			<th  style="border-left: 1px solid #C1DAD7"> Registration Number </th>
            <th  style="border-left: 1px solid #C1DAD7"> Name </th>
            <th  style="border-left: 1px solid #C1DAD7"> Score </th>
            <th  style="border-left: 1px solid #C1DAD7"> Remarks </th>
		</tr>
        <tbody>
        <?php
				include('../db.php');
				$userid= $_SESSION['SESS_MEMBER_ID'];
				$results = mysql_query("SELECT * FROM score");
				while($rows = mysql_fetch_array($results))
					{
					$score=$rows['passing'];	
					}
				$result = mysql_query("SELECT * FROM student where status='ready' ORDER BY refnumber ASC");
				while($row = mysql_fetch_array($result))
					{
						echo '<tr class="record">';
						echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['refnumber'].'</td>';
						echo '<td>'.$row['firstname'].' '.$row['middlename'].' '.$row['lastname'].'</td>';
						echo '<td><div align="right">'.$row['score'].'</div></td>';
						echo '<td><div align="right">';
						$ttata=$row['score'];
						if($ttata>=$score){
						echo 'Passed';
						}
						if($ttata<$score){
						echo 'Failed';
						}
						echo '</div></td>';
						echo '</tr>';
					}
				?> 
	</tbody>
</table>
</div>
<a href="javascript:Clickheretoprint()">Print</a>

