<?php
include('../db.php');
$refnumber=$_POST['refnum'];
$username=$_POST['username'];
$course=$_POST['course'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$mname=$_POST['mname'];
$stat='used';

$ref = mysql_query("SELECT * FROM reference where reference_number='$refnumber'");
$mine = mysql_num_rows($ref);

if($mine==0)
 {
	 echo '<script>';
echo 'alert("Registration Number doesnt match the one you were given. Contact the Admin!");';
echo 'location.href="index.php"';
echo '</script>';
 }
 
 else
 {

$result = mysql_query("SELECT * FROM student where refnumber='$refnumber'");
$count=mysql_num_rows($result);
if($count==0)
{
mysql_query("INSERT INTO student (refnumber, firstname, lastname, middlename, course, username) VALUES ('$refnumber', '$fname', '$lname', '$mname', '$course', '$username')");
mysql_query("UPDATE reference SET owner='$stat' WHERE reference_number='$refnumber'");
header("location: index.php");
}
else{
header("location: index.php");
}
 }
?>