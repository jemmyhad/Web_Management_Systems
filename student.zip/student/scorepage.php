<?php
include('../db.php');
$id=$_GET['id'];
$result = mysql_query("SELECT * FROM student WHERE id='$id'");
while($row = mysql_fetch_array($result))
	{
		$tempscore=$row['score'];
	}
?> 
<html>
<head>
</head>
<body style="background-color:green; width:100%; height:100%; margin:0; padding:0;">
<div style="text-align:center; padding:20px; border:1px solid #fff; width:300px; margin:30px auto; color:#fff;">
<?php

$strSQL = "SELECT * FROM student where id='$id' and status!='ready'";

	$rs = mysql_query($strSQL);
	
	
	while($row = mysql_fetch_array($rs)) {

	 echo "You scored ";
	  echo $row['score'] . " in your exam<br /> Your Essay will be checked by your Lecturer for final marks.<br />";

	  }

	// Close the database connection
	mysql_close();
?>
<a href="index.php">Logout</a>
</div>
</body>
</html>